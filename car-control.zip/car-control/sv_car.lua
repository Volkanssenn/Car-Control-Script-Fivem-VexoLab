print('^3[iPad-System] ################################^7')
print('^3[iPad-System] KONTROL PANELI AKTIFLESTIRILIYOR^7')
print('^3[iPad-System] ################################^7')

local QBCore = exports['qb-core']:GetCoreObject()
local VehicleRadios = {}

-- Database Initialization
CreateThread(function()
    Wait(2000) -- Wait for database startup
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS player_playlists (
            id INT AUTO_INCREMENT PRIMARY KEY,
            citizenid VARCHAR(50) NOT NULL,
            name VARCHAR(100) NOT NULL,
            tracks LONGTEXT, 
            UNIQUE KEY (citizenid, name)
        )
    ]], function()
        print('^2[iPad-System] VERITABANI BAGLANTISI BASARILI!^7')
    end)
end)

local function SyncList(src)
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    MySQL.query('SELECT * FROM player_playlists WHERE citizenid = ?', {Player.PlayerData.citizenid}, function(results)
        local pl = {}
        if results then
            for _, v in ipairs(results) do
                table.insert(pl, { id = v.id, name = v.name, tracks = json.decode(v.tracks or '[]') })
            end
        end
        print('^3[iPad-System] Oyuncuya '..#pl..' adet liste gonderildi.^7')
        TriggerClientEvent('car-control:client:ReceivePlaylists', src, pl)
    end)
end

-- Events
RegisterNetEvent('car-control:server:GetPlaylists', function()
    print('^5[iPad-System] Liste istendi: '..source..'^7')
    SyncList(source)
end)

RegisterNetEvent('car-control:server:SavePlaylist', function(name, tracks)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    local data = json.encode(tracks or {})
    print('^5[iPad-System] Kayit islemi basladi: '..name..'^7')
    MySQL.query('INSERT INTO player_playlists (citizenid, name, tracks) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE tracks = ?', 
    {Player.PlayerData.citizenid, name, data, data}, function()
        print('^2[iPad-System] Kayit tamamlandi!^7')
        SyncList(src)
    end)
end)

RegisterNetEvent('car-control:server:DeletePlaylist', function(name)
    local src = source
    local Player = QBCore.Functions.GetPlayer(src)
    if not Player then return end
    MySQL.query('DELETE FROM player_playlists WHERE citizenid = ? AND name = ?', {Player.PlayerData.citizenid, name}, function()
        SyncList(src)
    end)
end)

-- Radio Sync Core
RegisterNetEvent('car-control:server:UpdateRadio', function(netId, data)
    if not data or not data.url or data.url == "" then VehicleRadios[netId] = nil
    else
        VehicleRadios[netId] = {
            url = data.url, volume = data.volume or 50, isLoop = data.isLoop or false,
            isPaused = false, startTime = os.time() - (data.offset or 0),
            playlist = data.playlist or nil, trackIndex = data.trackIndex or 1
        }
    end
    TriggerClientEvent('car-control:client:SyncRadio', -1, netId, VehicleRadios[netId])
end)

RegisterNetEvent('car-control:server:TrackFinished', function(netId)
    local r = VehicleRadios[netId]
    if r and r.playlist then
        local n = r.trackIndex + 1
        if n <= #r.playlist.tracks then
            r.url = r.playlist.tracks[n].url; r.trackIndex = n; r.startTime = os.time()
            TriggerClientEvent('car-control:client:SyncRadio', -1, netId, r)
        else
            VehicleRadios[netId] = nil; TriggerClientEvent('car-control:client:SyncRadio', -1, netId, nil)
        end
    end
end)

RegisterNetEvent('car-control:server:togglePause', function(netId, paused)
    local r = VehicleRadios[netId]
    if r then
        r.isPaused = paused
        if paused then r.pauseTime = os.time()
        else r.startTime = r.startTime + (os.time() - (r.pauseTime or os.time())) end
        TriggerClientEvent('car-control:client:SyncRadio', -1, netId, r)
    end
end)

RegisterNetEvent('car-control:server:ChangeVolume', function(netId, vol)
    if VehicleRadios[netId] then VehicleRadios[netId].volume = vol; TriggerClientEvent('car-control:client:SyncRadio', -1, netId, VehicleRadios[netId]) end
end)

RegisterNetEvent('car-control:server:RequestRadios', function() TriggerClientEvent('car-control:client:InitialSync', source, VehicleRadios) end)
