-- BULLETPROOF MYSQL WRAPPER (V29)
if not MySQL then
    local driver = GetResourceState('oxmysql') == 'started' and exports.oxmysql or (GetResourceState('mysql-async') == 'started' and exports['mysql-async'] or nil)
    if driver then
        MySQL = {
            query = function(q, p, cb) driver:query(q, p, cb) end,
            insert = function(q, p, cb) driver:insert(q, p, cb) end,
            update = function(q, p, cb) driver:update(q, p, cb) end,
            scalar = function(q, p, cb) driver:scalar(q, p, cb) end,
            prepare = function(q, p, cb) driver:prepare(q, p, cb) end
        }
        print('^2[iPad-V3] MySQL Global Wrapper: Stabilized and Active.^7')
    else
        print('^1[iPad-V3] FATAL ERROR: No MySQL Driver Detected!^7')
    end
end

local QBCore = nil
-- Multi-Layer QBCore Fetch
local function InitQBCore()
    if QBCore then return QBCore end
    if GetResourceState('qb-core') == 'started' then
        QBCore = exports['qb-core']:GetCoreObject()
    end
    if not QBCore then
        TriggerEvent('QBCore:GetObject', function(obj) QBCore = obj end)
    end
    return QBCore
end

local VehicleRadios = {}

-- Database Boot with Startup Verification
CreateThread(function()
    while GetResourceState('oxmysql') ~= 'started' do Wait(1000) end
    MySQL.query([[
        CREATE TABLE IF NOT EXISTS player_playlists (
            id INT AUTO_INCREMENT PRIMARY KEY,
            citizenid VARCHAR(50) NOT NULL,
            name VARCHAR(100) NOT NULL,
            tracks LONGTEXT, 
            UNIQUE KEY (citizenid, name)
        )
    ]], function()
        print('^2[iPad-V3] INFO: Database table is verified.^7')
    end)
end)

-- Diagnostic Command
RegisterCommand('playlistkontrol', function(source)
    local src = source
    local Core = InitQBCore()
    if not Core then 
        TriggerClientEvent('QBCore:Notify', src, 'Hata: QBCore Bulunamadi!', 'error')
        return 
    end
    
    local Player = Core.Functions.GetPlayer(src)
    if Player then
        print('^2[iPad-V3] DEBUG: System is active for ' .. Player.PlayerData.citizenid .. '^7')
        TriggerClientEvent('QBCore:Notify', src, 'Sistem Aktif: ' .. Player.PlayerData.citizenid, 'success')
    else
        print('^1[iPad-V3] DEBUG: Player object missing for source ' .. tostring(src) .. '^7')
        TriggerClientEvent('QBCore:Notify', src, 'Hata: Oyuncu Bulunamadi!', 'error')
    end
end, false)

-- V3 Playlist Fetch Engine
local function V3_FetchPlaylists(src)
    local Core = InitQBCore()
    if not Core then return end
    local Player = Core.Functions.GetPlayer(src)
    if not Player then return end
    
    local citizenid = Player.PlayerData.citizenid
    MySQL.query('SELECT * FROM player_playlists WHERE citizenid = ?', {citizenid}, function(results)
        local formatted = {}
        if results then
            for _, v in ipairs(results) do
                table.insert(formatted, {
                    id = v.id,
                    name = v.name,
                    tracks = json.decode(v.tracks or '[]')
                })
            end
        end
        TriggerClientEvent('V3_car:ReceivePlaylists', src, formatted)
    end)
end

-- V3 Server Events
RegisterNetEvent('V3_car:GetPlaylists', function()
    V3_FetchPlaylists(source)
end)

RegisterNetEvent('V3_car:SavePlaylist', function(name, tracks)
    local src = source
    local Core = InitQBCore()
    if not Core then 
        print('^1[iPad-V3] FATAL: QBCore is NULL in SavePlaylist!^7')
        return 
    end
    
    local Player = Core.Functions.GetPlayer(src)
    if not Player then 
        print('^1[iPad-V3] ERROR: Player object not found for src: '..tostring(src)..'^7')
        return 
    end
    
    local cid = Player.PlayerData.citizenid
    local tracksJson = json.encode(tracks or {})
    
    print('^3[iPad-V3] >>> STARTING SAVE PROCESS <<< ^7')
    print('^3[iPad-V3] Target CID: ' .. tostring(cid))
    print('^3[iPad-V3] Playlist Name: ' .. tostring(name))
    print('^3[iPad-V3] Tracks Data length: ' .. string.len(tracksJson) .. ' characters')

    if not cid or cid == "" then
        print('^1[iPad-V3] ABORT: CitizenID is empty, cannot proceed with SQL.^7')
        return
    end

    print('^3[iPad-V3] Executing SQL Query now...^7')
    
    local query = 'INSERT INTO player_playlists (citizenid, name, tracks) VALUES (?, ?, ?) ON DUPLICATE KEY UPDATE tracks = VALUES(tracks)'
    MySQL.query(query, {cid, name, tracksJson}, function(result)
        if result then
            print('^2[iPad-V3] SQL COMPLETE! Result: ' .. json.encode(result) .. '^7')
            V3_FetchPlaylists(src)
            TriggerClientEvent('QBCore:Notify', src, 'Playlist Kaydedildi: '..name, 'success')
        else
            print('^1[iPad-V3] SQL FAILED! Result is nil or error type.^7')
            print('^1[iPad-V3] Query attempted: ' .. query .. '^7')
            TriggerClientEvent('QBCore:Notify', src, 'SQL Hatasi!', 'error')
        end
    end)
end)

RegisterNetEvent('V3_car:DeletePlaylist', function(name)
    local src = source
    local Core = InitQBCore()
    if not Core then return end
    local Player = Core.Functions.GetPlayer(src)
    if not Player then return end
    
    MySQL.query('DELETE FROM player_playlists WHERE citizenid = ? AND name = ?', {Player.PlayerData.citizenid, name}, function()
        V3_FetchPlaylists(src)
    end)
end)

-- V3 Radio Sync Protocol
RegisterNetEvent('V3_car:UpdateRadio', function(netId, data)
    if not data or not data.url or data.url == "" then VehicleRadios[netId] = nil
    else
        VehicleRadios[netId] = {
            url = data.url, volume = data.volume or 50, isLoop = data.isLoop or false,
            isPaused = false, startTime = os.time() - (data.offset or 0),
            playlist = data.playlist or nil, trackIndex = data.trackIndex or 1
        }
    end
    TriggerClientEvent('V3_car:SyncRadio', -1, netId, VehicleRadios[netId])
end)

RegisterNetEvent('V3_car:TrackFinished', function(netId)
    local r = VehicleRadios[netId]
    if r and r.playlist then
        local n = r.trackIndex + 1
        if n <= #r.playlist.tracks then
            print('^2[iPad-V3] Auto-Next: Playing track '..n..' of '..#r.playlist.tracks..'^7')
            r.url = r.playlist.tracks[n].url; r.trackIndex = n; r.startTime = os.time()
            TriggerClientEvent('V3_car:SyncRadio', -1, netId, r)
        else
            print('^3[iPad-V3] Playlist Finished for vehicle '..netId..'^7')
            VehicleRadios[netId] = nil; TriggerClientEvent('V3_car:SyncRadio', -1, netId, nil)
        end
    end
end)

RegisterNetEvent('V3_car:togglePause', function(netId, paused)
    local r = VehicleRadios[netId]
    if r then
        r.isPaused = paused
        if paused then r.pauseTime = os.time()
        else r.startTime = r.startTime + (os.time() - (r.pauseTime or os.time())) end
        TriggerClientEvent('V3_car:SyncRadio', -1, netId, r)
    end
end)

RegisterNetEvent('V3_car:ChangeVolume', function(netId, vol)
    if VehicleRadios[netId] then
        VehicleRadios[netId].volume = vol
        TriggerClientEvent('V3_car:SyncRadio', -1, netId, VehicleRadios[netId])
    end
end)

RegisterNetEvent('V3_car:ToggleLock', function(netId)
    local v = NetworkGetEntityFromNetworkId(netId)
    if DoesEntityExist(v) then
        local st = GetVehicleDoorLockStatus(v)
        local newSt = (st == 1 or st == 0) and 2 or 1
        SetVehicleDoorsLocked(v, newSt)
    end
end)

RegisterNetEvent('V3_car:RequestRadios', function() TriggerClientEvent('V3_car:InitialSync', source, VehicleRadios) end)
