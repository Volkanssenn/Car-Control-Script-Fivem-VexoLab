local isUIOpen = false
local inVehicle = false
local syncedRadios = {}

-- V3 UNIQUE KEY MAPPING
RegisterKeyMapping('V3_openPad', 'Open iPad Panel', 'keyboard', 'F4')

RegisterCommand('V3_openPad', function()
    local p = PlayerPedId()
    if IsPedInAnyVehicle(p, false) then ToggleUI() end
end, false)

function ToggleUI()
    isUIOpen = not isUIOpen
    SetNuiFocus(isUIOpen, isUIOpen)
    SendNUIMessage({ action = "toggleUI", display = isUIOpen })
    
    if isUIOpen then
        UpdateVehicleStatus()
        local v = GetVehiclePedIsIn(PlayerPedId(), false)
        if v ~= 0 then
            SendNUIMessage({
                action = "setRadioState",
                state = syncedRadios[VehToNet(v)],
                serverTime = GetCloudTimeAsInt()
            })
        end
    end
end

function UpdateVehicleStatus()
    local v = GetVehiclePedIsIn(PlayerPedId(), false)
    if v ~= 0 and DoesEntityExist(v) then
        local s = { locked = GetVehicleDoorLockStatus(v) == 2, doors = {}, engine = GetIsVehicleEngineRunning(v) }
        for i = 0, 5 do s.doors[tostring(i)] = GetVehicleDoorAngleRatio(v, i) > 0 end
        SendNUIMessage({ action = "updateStatus", status = s })
    end
end

-- Core Loops
CreateThread(function()
    TriggerServerEvent('V3_car:RequestRadios')
    while true do
        local ped = PlayerPedId()
        local current = IsPedInAnyVehicle(ped, false)
        if current ~= inVehicle then inVehicle = current; SendNUIMessage({ action = "setHint", show = inVehicle }) end
        if inVehicle and isUIOpen then UpdateVehicleStatus(); Wait(2000) else Wait(1000) end
    end
end)

-- Progress Bar and Auto-Next Safety Loop (V28)
local lastAutoTrigger = 0
CreateThread(function()
    while true do
        local v = GetVehiclePedIsIn(PlayerPedId(), false)
        if v ~= 0 then
            local netId = VehToNet(v)
            local sn = "veh_radio_" .. netId
            if GetResourceState('xsound') == 'started' and exports.xsound:soundExists(sn) then
                local info = exports.xsound:getInfo(sn)
                if info and info.maxDuration > 0 then
                    if isUIOpen then
                        SendNUIMessage({ action = "updateDuration", duration = info.maxDuration, serverTime = GetCloudTimeAsInt() })
                    end
                    
                    -- SAFETY AUTO-NEXT (If onPlayEnd fails)
                    local currentTime = exports.xsound:getTimeStamp(sn)
                    if currentTime >= (info.maxDuration - 1) and info.maxDuration > 5 then
                        if GetPedInVehicleSeat(v, -1) == PlayerPedId() then
                            if syncedRadios[netId] and syncedRadios[netId].playlist then
                                if GetGameTimer() - lastAutoTrigger > 5000 then -- 5s cooldown to prevent double trigger
                                    lastAutoTrigger = GetGameTimer()
                                    print('^3[iPad] Safety Auto-Next Triggered!^7')
                                    TriggerServerEvent('V3_car:TrackFinished', netId)
                                end
                            end
                        end
                    end
                end
            end
        end
        Wait(isUIOpen and 500 or 1500)
    end
end)

-- xSound Logic (Optimized)
local currentPlayingUrls = {}

function PlayVehicleRadio(netId, data)
    local sn = "veh_radio_" .. netId
    if GetResourceState('xsound') ~= 'started' then return end
    if NetworkDoesNetworkIdExist(netId) then
        local v = NetToVeh(netId)
        if DoesEntityExist(v) then
            -- URL CHANGE DETECTION (V28)
            if exports.xsound:soundExists(sn) and currentPlayingUrls[sn] ~= data.url then
                print('^3[iPad] URL Change Detected: Destroying old sound for '..sn..'^7')
                exports.xsound:Destroy(sn)
            end

            local offset = GetCloudTimeAsInt() - (data.startTime or GetCloudTimeAsInt())
            local vol = (data.volume or 50) / 100
            
            if exports.xsound:soundExists(sn) then
                exports.xsound:setVolumeMax(sn, vol)
                exports.xsound:setSoundLoop(sn, data.isLoop)
                if data.isPaused then exports.xsound:Pause(sn) else exports.xsound:Resume(sn) end
                if not data.isPaused and math.abs(exports.xsound:getTimeStamp(sn) - offset) > 3 then exports.xsound:setTimeStamp(sn, offset) end
            else
                currentPlayingUrls[sn] = data.url
                exports.xsound:PlayUrlPos(sn, data.url, vol, GetEntityCoords(v), data.isLoop)
                exports.xsound:Distance(sn, 30.0)
                if data.isPaused then exports.xsound:Pause(sn) end
                exports.xsound:onPlayStart(sn, function()
                    exports.xsound:setTimeStamp(sn, GetCloudTimeAsInt() - (data.startTime or GetCloudTimeAsInt()))
                    if data.isPaused then exports.xsound:Pause(sn) end
                end)
                exports.xsound:onPlayEnd(sn, function()
                    if GetPedInVehicleSeat(NetToVeh(netId), -1) == PlayerPedId() then TriggerServerEvent('V3_car:TrackFinished', netId) end
                end)
            end
        end
    end
end

CreateThread(function()
    while true do
        local waitTime = 500
        if GetResourceState('xsound') == 'started' then
            local ped = PlayerPedId()
            local pCoords = GetEntityCoords(ped)
            local currentVeh = GetVehiclePedIsIn(ped, false)
            
            for nid, d in pairs(syncedRadios) do
                if NetworkDoesNetworkIdExist(nid) then
                    local v = NetToVeh(nid)
                    if DoesEntityExist(v) then
                        local sn = "veh_radio_" .. nid
                        local vCoords = GetEntityCoords(v)
                        local dist = #(pCoords - vCoords)
                        
                        if exports.xsound:soundExists(sn) then
                            if dist < 50.0 then
                                -- FIX: If we are inside, set position to our head to avoid volume drop at high speed
                                if v == currentVeh then
                                    exports.xsound:Position(sn, pCoords)
                                else
                                    exports.xsound:Position(sn, vCoords)
                                end
                                
                                -- Determine the best wait time based on proximity
                                if v == currentVeh then
                                    if waitTime > 10 then waitTime = 10 end -- High frequency for driver/passenger
                                elseif dist < 15.0 then
                                    if waitTime > 50 then waitTime = 50 end -- Fast for nearby observers
                                elseif dist < 50.0 then
                                    if waitTime > 100 then waitTime = 100 end -- Normal for distant observers
                                end
                            end
                        elseif dist < 45.0 then 
                            PlayVehicleRadio(nid, d) 
                        end
                    end
                else syncedRadios[nid] = nil end
            end
        end
        Wait(waitTime)
    end
end)

-- V3 SYNC EVENTS
RegisterNetEvent('V3_car:SyncRadio', function(netId, data)
    syncedRadios[netId] = data
    if data then PlayVehicleRadio(netId, data)
    else local sn = "veh_radio_" .. netId; if exports.xsound:soundExists(sn) then exports.xsound:Destroy(sn) end end
    if isUIOpen then
        local v = GetVehiclePedIsIn(PlayerPedId(), false)
        if v ~= 0 and VehToNet(v) == netId then SendNUIMessage({ action = "setRadioState", state = data, serverTime = GetCloudTimeAsInt() }) end
    end
end)

RegisterNetEvent('V3_car:ReceivePlaylists', function(pl)
    if isUIOpen then SendNUIMessage({ action = "receivePlaylists", playlists = pl }) end
end)

RegisterNetEvent('V3_car:InitialSync', function(r) syncedRadios = r end)

-- V3 Callbacks
RegisterNUICallback('close', function(_, cb) isUIOpen = false; SetNuiFocus(false, false); SendNUIMessage({ action = "toggleUI", display = false }); cb('ok') end)
RegisterNUICallback('toggleDoor', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then
        local d = tonumber(data.door)
        if GetVehicleDoorAngleRatio(v, d) > 0 then SetVehicleDoorShut(v, d, false) else SetVehicleDoorOpen(v, d, false, false) end
        UpdateVehicleStatus()
    end; cb('ok')
end)
RegisterNUICallback('toggleLock', function(_, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false)
    if v ~= 0 then TriggerServerEvent('V3_car:ToggleLock', VehToNet(v)); Wait(100); UpdateVehicleStatus() end; cb('ok')
end)
RegisterNUICallback('switchSeat', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 and IsVehicleSeatFree(v, tonumber(data.seat)) then SetPedIntoVehicle(PlayerPedId(), v, tonumber(data.seat)) end; cb('ok')
end)
RegisterNUICallback('changeVolume', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('V3_car:ChangeVolume', VehToNet(v), tonumber(data.volume)) end; cb('ok')
end)
RegisterNUICallback('updateRadio', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('V3_car:UpdateRadio', VehToNet(v), data) end; cb('ok')
end)
RegisterNUICallback('togglePause', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('V3_car:togglePause', VehToNet(v), data.paused) end; cb('ok')
end)

-- V3 PLAYLIST CALLBACKS
RegisterNUICallback('GetPlaylists', function(_, cb) TriggerServerEvent('V3_car:GetPlaylists'); cb('ok') end)
RegisterNUICallback('SavePlaylist', function(data, cb) TriggerServerEvent('V3_car:SavePlaylist', data.name, data.tracks); cb('ok') end)
RegisterNUICallback('DeletePlaylist', function(data, cb) TriggerServerEvent('V3_car:DeletePlaylist', data.name); cb('ok') end)

RegisterNUICallback('stopRadio', function(_, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('V3_car:UpdateRadio', VehToNet(v), {}) end; cb('ok')
end)
