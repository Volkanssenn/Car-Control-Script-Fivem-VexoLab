Locales = {}

Locales['en'] = {
    -- Hint
    ["hint_label"] = "Control Panel",
    -- Tabs/Headers
    ["tab_doors"] = "Vehicle Control",
    ["tab_seats"] = "Seat Selection",
    ["tab_radio"] = "Music & Radio",
    -- Doors
    ["door_hood"] = "Hood",
    ["door_front_left"] = "Front Left",
    ["door_front_right"] = "Front Right",
    ["door_back_left"] = "Back Left",
    ["door_back_right"] = "Back Right",
    ["door_trunk"] = "Trunk",
    -- Radio
    ["radio_placeholder"] = "Enter YouTube URL...",
    ["radio_playlist_default"] = "Select Playlist...",
    ["radio_add_btn"] = "Add",
    ["radio_waiting"] = "Waiting for Music...",
    ["radio_play"] = "Play",
    ["radio_pause"] = "Pause",
    ["radio_my_playlists"] = "My Playlists",
    ["radio_all_tracks"] = "All Tracks",
    ["radio_play_all"] = "Play All",
    ["radio_back"] = "Back",
    -- Modals
    ["modal_new_playlist"] = "New Playlist",
    ["modal_pl_placeholder"] = "Enter playlist name...",
    ["modal_cancel"] = "Cancel",
    ["modal_create"] = "Create",
    -- Server Notifications
    ["err_no_qb"] = "Error: QBCore Not Found!",
    ["notify_active"] = "System Active for: ",
    ["err_no_player"] = "Error: Player Not Found!",
    ["notify_playlist_saved"] = "Playlist Saved: ",
    ["err_sql"] = "SQL Error!",
}

Locales['tr'] = {
    -- Hint
    ["hint_label"] = "Kontrol Paneli",
    -- Tabs/Headers
    ["tab_doors"] = "Araç Kontrolü",
    ["tab_seats"] = "Koltuk Seçimi",
    ["tab_radio"] = "Müzik & Radyo",
    -- Doors
    ["door_hood"] = "Kaput",
    ["door_front_left"] = "Ön Sol",
    ["door_front_right"] = "Ön Sağ",
    ["door_back_left"] = "Arka Sol",
    ["door_back_right"] = "Arka Sağ",
    ["door_trunk"] = "Bagaj",
    -- Radio
    ["radio_placeholder"] = "YouTube URL girin...",
    ["radio_playlist_default"] = "Playlist Seçin...",
    ["radio_add_btn"] = "Ekle",
    ["radio_waiting"] = "Müzik Bekleniyor...",
    ["radio_play"] = "Oynat",
    ["radio_pause"] = "Duraklat",
    ["radio_my_playlists"] = "Playlistlerim",
    ["radio_all_tracks"] = "Tüm Parçalar",
    ["radio_play_all"] = "Tümünü Çal",
    ["radio_back"] = "Geri",
    -- Modals
    ["modal_new_playlist"] = "Yeni Playlist",
    ["modal_pl_placeholder"] = "Liste adını girin...",
    ["modal_cancel"] = "İptal",
    ["modal_create"] = "Oluştur",
    -- Server Notifications
    ["err_no_qb"] = "Hata: QBCore Bulunamadı!",
    ["notify_active"] = "Sistem Aktif: ",
    ["err_no_player"] = "Hata: Oyuncu Bulunamadı!",
    ["notify_playlist_saved"] = "Playlist Kaydedildi: ",
    ["err_sql"] = "SQL Hatası!",
}

Locales['fr'] = {
    -- Hint
    ["hint_label"] = "Panneau de Contrôle",
    -- Tabs/Headers
    ["tab_doors"] = "Contrôle du Véhicule",
    ["tab_seats"] = "Sélection de Siège",
    ["tab_radio"] = "Musique & Radio",
    -- Doors
    ["door_hood"] = "Capot",
    ["door_front_left"] = "Avant Gauche",
    ["door_front_right"] = "Avant Droit",
    ["door_back_left"] = "Arrière Gauche",
    ["door_back_right"] = "Arrière Droit",
    ["door_trunk"] = "Coffre",
    -- Radio
    ["radio_placeholder"] = "Entrez l'URL YouTube...",
    ["radio_playlist_default"] = "Choisir une Playlist...",
    ["radio_add_btn"] = "Ajouter",
    ["radio_waiting"] = "En attente de musique...",
    ["radio_play"] = "Lire",
    ["radio_pause"] = "Pause",
    ["radio_my_playlists"] = "Mes Playlists",
    ["radio_all_tracks"] = "Toutes les pistes",
    ["radio_play_all"] = "Tout lire",
    ["radio_back"] = "Retour",
    -- Modals
    ["modal_new_playlist"] = "Nouvelle Playlist",
    ["modal_pl_placeholder"] = "Entrez le nom de la liste...",
    ["modal_cancel"] = "Annuler",
    ["modal_create"] = "Créer",
    -- Server Notifications
    ["err_no_qb"] = "Erreur: QBCore introuvable!",
    ["notify_active"] = "Système actif pour: ",
    ["err_no_player"] = "Erreur: Joueur introuvable!",
    ["notify_playlist_saved"] = "Playlist enregistrée: ",
    ["err_sql"] = "Erreur SQL!",
}

Locales['es'] = {
    -- Hint
    ["hint_label"] = "Panel de Control",
    -- Tabs/Headers
    ["tab_doors"] = "Control del Vehículo",
    ["tab_seats"] = "Selección de Asiento",
    ["tab_radio"] = "Música y Radio",
    -- Doors
    ["door_hood"] = "Capó",
    ["door_front_left"] = "Delantero Izquierdo",
    ["door_front_right"] = "Delantero Derecho",
    ["door_back_left"] = "Trasero Izquierdo",
    ["door_back_right"] = "Trasero Derecho",
    ["door_trunk"] = "Maletero",
    -- Radio
    ["radio_placeholder"] = "Ingrese URL de YouTube...",
    ["radio_playlist_default"] = "Seleccionar Playlist...",
    ["radio_add_btn"] = "Añadir",
    ["radio_waiting"] = "Esperando música...",
    ["radio_play"] = "Reproducir",
    ["radio_pause"] = "Pausa",
    ["radio_my_playlists"] = "Mis Playlists",
    ["radio_all_tracks"] = "Todas las pistas",
    ["radio_play_all"] = "Reproducir todo",
    ["radio_back"] = "Volver",
    -- Modals
    ["modal_new_playlist"] = "Nueva Playlist",
    ["modal_pl_placeholder"] = "Ingrese el nombre de la lista...",
    ["modal_cancel"] = "Cancelar",
    ["modal_create"] = "Crear",
    -- Server Notifications
    ["err_no_qb"] = "Error: ¡QBCore no encontrado!",
    ["notify_active"] = "Sistema activo para: ",
    ["err_no_player"] = "Error: ¡Jugador no encontrado!",
    ["notify_playlist_saved"] = "Playlist guardada: ",
    ["err_sql"] = "¡Error de SQL!",
}

function _L(key)
    if Locales[Config.Lang] and Locales[Config.Lang][key] then
        return Locales[Config.Lang][key]
    elseif Locales['en'] and Locales['en'][key] then
        return Locales['en'][key]
    end
    return key
end
