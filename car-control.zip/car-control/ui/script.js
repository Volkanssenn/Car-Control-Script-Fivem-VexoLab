console.log('%c [iPad-Stable] Radio Logic Active ', 'background: #111; color: #00FF00');

let isLoopActive = false;
let currentStartTime = 0;
let totalDuration = 0;
let timeOffset = 0;
let timerInterval = null;
let isPaused = false;

let myPlaylists = [];
let activePlaylistId = null;

// UI Message Receiver
window.addEventListener('message', function(event) {
    const data = event.data;
    if (data.action === "toggleUI") {
        const wrapper = document.getElementById('ipad-wrapper');
        if (data.display) {
            wrapper.classList.remove('hidden');
            startTimer();
            post('GetPlaylists', {}); 
        } else {
            wrapper.classList.add('hidden');
            stopTimer();
            document.getElementById('playlist-modal').classList.add('hidden');
        }
    }

    if (data.action === "setRadioState") {
        if (data.state) {
            document.getElementById('radio-url').value = data.state.url;
            document.getElementById('volume-slider').value = data.state.volume;
            document.getElementById('volume-text').textContent = data.state.volume + "%";
            isLoopActive = data.state.isLoop;
            if (isLoopActive) document.getElementById('loop-btn').classList.add('active');
            else document.getElementById('loop-btn').classList.remove('active');
            isPaused = data.state.isPaused || false;
            updatePauseButtonUI();
            currentStartTime = data.state.startTime;
            if (data.serverTime) timeOffset = data.serverTime - (Date.now() / 1000);
            fetchSongTitle(data.state.url);
        } else {
            document.getElementById('radio-url').value = "";
            document.getElementById('song-name').textContent = "Müzik Bekleniyor...";
            currentStartTime = 0; totalDuration = 0; isPaused = false;
            updatePauseButtonUI(); resetUI();
        }
    }

    if (data.action === "receivePlaylists") {
        myPlaylists = data.playlists;
        renderPlaylists();
        updatePlaylistDropdown();
    }

    if (data.action === "updateDuration") {
        totalDuration = data.duration;
        if (data.serverTime) timeOffset = data.serverTime - (Date.now() / 1000);
    }

    if (data.action === "updateStatus") updateVehicleUI(data.status);
    
    if (data.action === "setHint") {
        const hint = document.getElementById('hint-container');
        if (data.show) hint.classList.remove('hidden');
        else hint.classList.add('hidden');
    }
});

// Sidebar Navigation
const navItems = document.querySelectorAll('.nav-item');
navItems.forEach(item => {
    item.addEventListener('click', () => {
        const tabId = item.getAttribute('data-tab');
        if (!tabId) return;
        navItems.forEach(i => i.classList.remove('active'));
        item.classList.add('active');
        document.querySelectorAll('.tab-content').forEach(c => c.classList.remove('active'));
        document.getElementById(tabId).classList.add('active');
    });
});

// Playlist Logic
function renderPlaylists() {
    const list = document.getElementById('pl-list');
    list.innerHTML = "";
    myPlaylists.forEach(pl => {
        const div = document.createElement('div');
        div.className = "pl-item";
        div.innerHTML = `<span>${pl.name}</span><i data-lucide="chevron-right"></i>`;
        div.onclick = () => showPlaylistTracks(pl.id);
        list.appendChild(div);
    });
    if (window.lucide) lucide.createIcons();
}

function updatePlaylistDropdown() {
    const select = document.getElementById('pl-dropdown');
    if (!select) return;
    select.innerHTML = '<option value="">Playlist Seçin...</option>';
    myPlaylists.forEach(pl => {
        const opt = document.createElement('option');
        opt.value = pl.id;
        opt.textContent = pl.name;
        select.appendChild(opt);
    });
}

function showPlaylistTracks(plId) {
    const pl = myPlaylists.find(p => p.id === plId);
    if (!pl) return;
    activePlaylistId = plId;
    document.getElementById('active-pl-name').textContent = pl.name;
    document.getElementById('pl-list').classList.add('hidden');
    document.getElementById('pl-tracks-container').classList.remove('hidden');
    
    const list = document.getElementById('tracks-list');
    list.innerHTML = "";
    pl.tracks.forEach((track, index) => {
        const div = document.createElement('div');
        div.className = "track-item";
        div.innerHTML = `<span>${index + 1}. ${track.title || 'Bilinmeyen'}</span><i data-lucide="trash-2" class="track-delete"></i>`;
        div.querySelector('.track-delete').onclick = (e) => { e.stopPropagation(); deleteTrack(index); };
        div.onclick = () => { 
            post('updateRadio', { 
                url: track.url, 
                volume: document.getElementById('volume-slider').value, 
                isLoop: false, 
                offset: 0,
                playlist: pl,
                trackIndex: index + 1 // Pass the current index + 1
            }); 
        };
        list.appendChild(div);
    });
    if (window.lucide) lucide.createIcons();
}

function deleteTrack(index) {
    const pl = myPlaylists.find(p => p.id === activePlaylistId);
    if (!pl) return;
    pl.tracks.splice(index, 1);
    post('SavePlaylist', { name: pl.name, tracks: pl.tracks });
    showPlaylistTracks(activePlaylistId);
}

// Button Events
document.getElementById('create-pl-btn').onclick = () => {
    document.getElementById('playlist-modal').classList.remove('hidden');
};

document.getElementById('modal-cancel').onclick = () => {
    document.getElementById('playlist-modal').classList.add('hidden');
};

document.getElementById('modal-create').onclick = () => {
    const nameInput = document.getElementById('new-pl-name');
    const name = nameInput.value.trim();
    if (name) {
        post('SavePlaylist', { name: name, tracks: [] });
        nameInput.value = "";
        document.getElementById('playlist-modal').classList.add('hidden');
    }
};

document.getElementById('back-to-pl').onclick = () => {
    document.getElementById('pl-tracks-container').classList.add('hidden');
    document.getElementById('pl-list').classList.remove('hidden');
};

document.getElementById('add-to-pl-btn').onclick = () => {
    document.getElementById('pl-select-container').classList.toggle('hidden');
};

document.getElementById('confirm-add-btn').onclick = () => {
    const url = document.getElementById('radio-url').value;
    const plId = document.getElementById('pl-dropdown').value;
    if (!url || !plId) return;

    fetch(`https://noembed.com/embed?url=${url}`)
        .then(res => res.json())
        .then(meta => {
            const pl = myPlaylists.find(p => p.id == plId);
            if (pl) {
                pl.tracks.push({ url: url, title: meta.title || "YouTube Videosu" });
                post('SavePlaylist', { name: pl.name, tracks: pl.tracks });
                document.getElementById('pl-select-container').classList.add('hidden');
            }
        });
};

document.getElementById('play-pl-btn').onclick = () => {
    const pl = myPlaylists.find(p => p.id === activePlaylistId);
    if (pl && pl.tracks.length > 0) {
        console.log('[iPad] Playing All Tracks for playlist:', pl.name);
        post('updateRadio', {
            url: pl.tracks[0].url, 
            volume: document.getElementById('volume-slider').value,
            isLoop: false, 
            offset: 0, 
            playlist: pl, 
            trackIndex: 1
        });
        // Feedback
        document.getElementById('song-name').textContent = "Playlist Başlatıldı...";
    }
};

// Controls
document.getElementById('play-btn').onclick = function() {
    const url = document.getElementById('radio-url').value;
    if (url) post('updateRadio', { url: url, volume: document.getElementById('volume-slider').value, isLoop: isLoopActive, offset: 0 });
};

document.getElementById('pause-btn').onclick = function() {
    if (currentStartTime > 0) { isPaused = !isPaused; post('togglePause', { paused: isPaused }); updatePauseButtonUI(); }
};

document.getElementById('loop-btn').onclick = function() {
    isLoopActive = !isLoopActive;
    this.classList.toggle('active');
};

document.getElementById('volume-slider').oninput = function() {
    document.getElementById('volume-text').textContent = this.value + "%";
    post('changeVolume', { volume: this.value });
};

document.getElementById('seek-slider').onchange = function() {
    if (totalDuration > 0) {
        const seekTo = (this.value / 100) * totalDuration;
        post('updateRadio', { url: document.getElementById('radio-url').value, volume: document.getElementById('volume-slider').value, isLoop: isLoopActive, offset: seekTo });
    }
};

// Doors & Seats
document.querySelectorAll('.door-btn').forEach(btn => {
    btn.onclick = () => { post('toggleDoor', { door: btn.getAttribute('data-door') }); };
});

document.querySelectorAll('.seat').forEach(btn => {
    btn.onclick = () => { post('switchSeat', { seat: btn.getAttribute('data-seat') }); };
});

document.getElementById('main-lock').onclick = () => post('toggleLock', {});

// Helpers
function fetchSongTitle(url) {
    if (!url) return;
    fetch(`https://noembed.com/embed?url=${url}`)
        .then(res => res.json())
        .then(data => { document.getElementById('song-name').textContent = data.title || "Çalıyor..."; })
        .catch(() => { document.getElementById('song-name').textContent = "YouTube Video"; });
}

function updatePauseButtonUI() {
    const btn = document.getElementById('pause-btn');
    if (isPaused) { btn.classList.add('paused'); btn.innerHTML = '<i data-lucide="play"></i> Devam Et'; }
    else { btn.classList.remove('paused'); btn.innerHTML = '<i data-lucide="pause"></i> Duraklat'; }
    if (window.lucide) lucide.createIcons();
}

function resetUI() {
    document.getElementById('seek-slider').value = 0;
    document.getElementById('current-time').textContent = "00:00";
    document.getElementById('duration').textContent = "00:00";
}

function startTimer() {
    if (timerInterval) clearInterval(timerInterval);
    timerInterval = setInterval(() => {
        if (currentStartTime > 0 && !isPaused) {
            const now = (Date.now() / 1000) + timeOffset;
            let currentSec = now - currentStartTime;
            if (currentSec < 0) currentSec = 0;
            if (totalDuration > 0 && currentSec > totalDuration) {
                currentSec = isLoopActive ? (currentSec % totalDuration) : totalDuration;
            }
            document.getElementById('current-time').textContent = formatTime(currentSec);
            if (totalDuration > 0) {
                document.getElementById('duration').textContent = formatTime(totalDuration);
                document.getElementById('seek-slider').value = (currentSec / totalDuration) * 100;
                document.getElementById('seek-slider').disabled = false;
                document.getElementById('seek-slider').style.opacity = "1";
            } else {
                document.getElementById('duration').textContent = "Yükleniyor...";
                document.getElementById('seek-slider').value = 0;
                document.getElementById('seek-slider').disabled = true;
                document.getElementById('seek-slider').style.opacity = "0.5";
            }
        }
    }, 200);
}

function stopTimer() { if (timerInterval) clearInterval(timerInterval); }

function formatTime(seconds) {
    const s = Math.floor(seconds);
    const m = Math.floor(s / 60);
    return `${String(m).padStart(2, '0')}:${String(s % 60).padStart(2, '0')}`;
}

function updateVehicleUI(s) {
    document.querySelectorAll('.door-btn').forEach(btn => {
        if (s.doors[btn.getAttribute('data-door')]) btn.classList.add('open'); else btn.classList.remove('open');
    });
    const lb = document.getElementById('main-lock');
    if (lb) { if (s.locked) lb.classList.add('locked'); else lb.classList.remove('locked'); }
    if (window.lucide) lucide.createIcons();
}

document.getElementById('close-btn').onclick = () => post('close', {});
window.addEventListener('keydown', (e) => { if (e.key === 'Escape' || e.key === 'F4') post('close', {}); });

// ULTIMATE STABLE POST METHOD (XHR)
function post(ev, data) {
    const rName = window.GetParentResourceName ? GetParentResourceName() : 'car-control';
    const xhr = new XMLHttpRequest();
    xhr.open('POST', `https://${rName}/${ev}`, true);
    xhr.setRequestHeader('Content-Type', 'application/json; charset=UTF-8');
    xhr.onreadystatechange = function() {
        if (xhr.readyState === 4) {
            if (xhr.status === 200) console.log(`[iPad-Stable] Signal ${ev} OK`);
            else console.error(`[iPad-Stable] Signal ${ev} FAIL (${xhr.status})`);
        }
    };
    xhr.send(JSON.stringify(data || {}));
}

function updateTime() {
    const now = new Date();
    document.getElementById('time').textContent = `${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
}
setInterval(updateTime, 60000); updateTime(); if (window.lucide) lucide.createIcons();
