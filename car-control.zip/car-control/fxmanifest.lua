fx_version 'cerulean'
game 'gta5'
description 'Premium iPad Car Control - V3 Stable'
version '3.0.0'

ui_page 'ui/index.html'

files {
    'ui/index.html',
    'ui/style.css',
    'ui/script.js'
}

client_scripts {
    'client.lua'
}

server_scripts {
    '@oxmysql/lib/MySQL.lua',
    'server.lua'
}

dependency 'xsound'
dependency 'oxmysql'
