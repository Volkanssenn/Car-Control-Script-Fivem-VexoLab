local isUIOpen = false
local inVehicle = false
local syncedRadios = {}

RegisterKeyMapping('toggleCarControl', 'Open Car Control Panel', 'keyboard', 'Y')

RegisterCommand('toggleCarControl', function()
    if IsPedInAnyVehicle(PlayerPedId(), false) then ToggleUI() end
end, false)

function ToggleUI()
    isUIOpen = not isUIOpen
    SetNuiFocus(isUIOpen, isUIOpen)
    SendNUIMessage({ action = "toggleUI", display = isUIOpen })
    if isUIOpen then
        UpdateVehicleStatus()
        local v = GetVehiclePedIsIn(PlayerPedId(), false)
        if v ~= 0 then
            SendNUIMessage({ action = "setRadioState", state = syncedRadios[VehToNet(v)], serverTime = GetCloudTimeAsInt() })
        end
    end
end

function UpdateVehicleStatus()
    local v = GetVehiclePedIsIn(PlayerPedId(), false)
    if v ~= 0 then
        local status = { locked = GetVehicleDoorLockStatus(v) == 2, doors = {}, engine = GetIsVehicleEngineRunning(v) }
        for i = 0, 5 do status.doors[tostring(i)] = GetVehicleDoorAngleRatio(v, i) > 0 end
        SendNUIMessage({ action = "updateStatus", status = status })
    end
end

CreateThread(function()
    TriggerServerEvent('car-control:server:RequestRadios')
    while true do
        local ped = PlayerPedId()
        local current = IsPedInAnyVehicle(ped, false)
        if current ~= inVehicle then inVehicle = current; SendNUIMessage({ action = "setHint", show = inVehicle }) end
        if inVehicle and isUIOpen then UpdateVehicleStatus(); Wait(2000) else Wait(1000) end
    end
end)

CreateThread(function()
    while true do
        if isUIOpen then
            local v = GetVehiclePedIsIn(PlayerPedId(), false)
            if v ~= 0 then
                local sn = "veh_radio_" .. VehToNet(v)
                if GetResourceState('xsound') == 'started' and exports.xsound:soundExists(sn) then
                    local info = exports.xsound:getInfo(sn)
                    if info and info.maxDuration > 0 then SendNUIMessage({ action = "updateDuration", duration = info.maxDuration, serverTime = GetCloudTimeAsInt() }) end
                end
            end
        end
        Wait(500)
    end
end)

function PlayVehicleRadio(netId, data)
    local sn = "veh_radio_" .. netId
    if GetResourceState('xsound') ~= 'started' then return end
    if NetworkDoesNetworkIdExist(netId) then
        local v = NetToVeh(netId)
        if DoesEntityExist(v) then
            local pos = GetEntityCoords(v)
            local offset = GetCloudTimeAsInt() - (data.startTime or GetCloudTimeAsInt())
            local vol = (data.volume or 50) / 100
            if exports.xsound:soundExists(sn) then
                exports.xsound:setVolumeMax(sn, vol); exports.xsound:setSoundLoop(sn, data.isLoop)
                if data.isPaused then exports.xsound:Pause(sn) else exports.xsound:Resume(sn) end
                if not data.isPaused and math.abs(exports.xsound:getTimeStamp(sn) - offset) > 3 then exports.xsound:setTimeStamp(sn, offset) end
            else
                exports.xsound:PlayUrlPos(sn, data.url, vol, pos, data.isLoop)
                exports.xsound:Distance(sn, 8.0)
                if data.isPaused then exports.xsound:Pause(sn) end
                exports.xsound:onPlayStart(sn, function()
                    exports.xsound:setTimeStamp(sn, GetCloudTimeAsInt() - (data.startTime or GetCloudTimeAsInt()))
                    if data.isPaused then exports.xsound:Pause(sn) end
                end)
                exports.xsound:onPlayEnd(sn, function()
                    local veh = NetToVeh(netId)
                    if DoesEntityExist(veh) and GetPedInVehicleSeat(veh, -1) == PlayerPedId() then TriggerServerEvent('car-control:server:TrackFinished', netId) end
                end)
            end
        end
    end
end

CreateThread(function()
    while true do
        if GetResourceState('xsound') == 'started' then
            for nid, d in pairs(syncedRadios) do
                if NetworkDoesNetworkIdExist(nid) then
                    local v = NetToVeh(nid)
                    if DoesEntityExist(v) then
                        local sn = "veh_radio_" .. nid
                        if exports.xsound:soundExists(sn) then exports.xsound:Position(sn, GetEntityCoords(v))
                        elseif #(GetEntityCoords(PlayerPedId()) - GetEntityCoords(v)) < 40.0 then PlayVehicleRadio(nid, d) end
                    end
                else syncedRadios[nid] = nil end
            end
        end
        Wait(500)
    end
end)

RegisterNetEvent('car-control:client:SyncRadio', function(netId, data)
    syncedRadios[netId] = data
    if data then PlayVehicleRadio(netId, data)
    else local sn = "veh_radio_" .. netId; if exports.xsound:soundExists(sn) then exports.xsound:Destroy(sn) end end
    if isUIOpen then
        local v = GetVehiclePedIsIn(PlayerPedId(), false)
        if v ~= 0 and VehToNet(v) == netId then SendNUIMessage({ action = "setRadioState", state = data, serverTime = GetCloudTimeAsInt() }) end
    end
end)

RegisterNetEvent('car-control:client:ReceivePlaylists', function(pl)
    if isUIOpen then SendNUIMessage({ action = "receivePlaylists", playlists = pl }) end
end)

RegisterNetEvent('car-control:client:InitialSync', function(r) syncedRadios = r end)

RegisterNUICallback('close', function(_, cb) isUIOpen = false; SetNuiFocus(false, false); SendNUIMessage({ action = "toggleUI", display = false }); cb('ok') end)
RegisterNUICallback('toggleDoor', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false)
    if v ~= 0 then
        local d = tonumber(data.door)
        if GetVehicleDoorAngleRatio(v, d) > 0 then SetVehicleDoorShut(v, d, false) else SetVehicleDoorOpen(v, d, false, false) end
        UpdateVehicleStatus()
    end
    cb('ok')
end)
RegisterNUICallback('toggleLock', function(_, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false)
    if v ~= 0 then local st = GetVehicleDoorLockStatus(v); SetVehicleDoorLockStatus(v, (st == 1 or st == 0) and 2 or 1); UpdateVehicleStatus() end
    cb('ok')
end)
RegisterNUICallback('switchSeat', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 and IsVehicleSeatFree(v, tonumber(data.seat)) then SetPedIntoVehicle(PlayerPedId(), v, tonumber(data.seat)) end
    cb('ok')
end)
RegisterNUICallback('changeVolume', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('car-control:server:ChangeVolume', VehToNet(v), tonumber(data.volume)) end
    cb('ok')
end)
RegisterNUICallback('updateRadio', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('car-control:server:UpdateRadio', VehToNet(v), data) end
    cb('ok')
end)
RegisterNUICallback('togglePause', function(data, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('car-control:server:togglePause', VehToNet(v), data.paused) end
    cb('ok')
end)
RegisterNUICallback('GetPlaylists', function(_, cb) TriggerServerEvent('car-control:server:GetPlaylists'); cb('ok') end)
RegisterNUICallback('SavePlaylist', function(data, cb) TriggerServerEvent('car-control:server:SavePlaylist', data.name, data.tracks); cb('ok') end)
RegisterNUICallback('DeletePlaylist', function(data, cb) TriggerServerEvent('car-control:server:DeletePlaylist', data.name); cb('ok') end)
RegisterNUICallback('stopRadio', function(_, cb)
    local v = GetVehiclePedIsIn(PlayerPedId(), false); if v ~= 0 then TriggerServerEvent('car-control:server:UpdateRadio', VehToNet(v), {}) end
    cb('ok')
end)
