Config = {}

-- [[ Language Selection ]] --
-- Supported: 'en' (English), 'tr' (Turkish), 'fr' (French), 'es' (Spanish)
Config.Lang = 'tr'
Config.OpenKey = 'H' -- Default key to open the panel
